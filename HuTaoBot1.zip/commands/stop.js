const {EmbedBuilder} = require('discord.js');
const { getVoiceConnection } = require('@discordjs/voice');
const {EMBED_COLORS} = require('../config')

module.exports = {
    name: 'stop',
    description: 'หยุดไม่ให้บอทเล่นเพลง',

    run: async(interaction, client) =>{
        const player = interaction.client.manager.get(interaction.guild.id);
        if(!player) return interaction.reply({content: `❌ **| ไม่มีเพลงเล่นในขณะนี้...**`, ephemeral: true});
        const channel = interaction.member.voice.channel;
        const botChannel = interaction.guild.members.me.voice.channel;

        if(!channel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.**`, ephemeral: true});
        if(channel && channel != botChannel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.**`, ephemeral: true});
        
        await player.destroy();
        player.queue.clear();
        const embed = new EmbedBuilder  ()
        .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
        .setDescription(`> **✅ As you wish...**`)
        .addFields([
            {name: `senpai~!<a:Down_arrow_red:1126104355116957767>`, value: ("`" + interaction.member.user.username + "`"), inline: true}
        ])
        .setColor(EMBED_COLORS.STOP)
        try {
            await interaction.reply({embeds: [embed]})
        }catch{}

    
    
    }
}