const {MessageEmbed} = require('discord.js');
const { MUSIC } = require('../../config');



module.exports = async(player) =>{
    setTimeout(() =>{
        if(player.state === 'CONNECTED' && player.queue.size === 0 && !player.playing) player.destroy();
    }, MUSIC.IDLE_TIME * 1000)
}

