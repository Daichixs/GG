const {EmbedBuilder} = require('discord.js')
const {EMBED_COLORS} = require('../config')

module.exports = {
    name: 'skipto',
    description: 'ข้ามไปยังแทร็กที่ต้องการจากคิว',
    options:[
        {
            name: 'ตำแหน่ง',
            description: 'หมายเลขแทร็กจากคิว',
            type: 4,
            required: true,
        }
    ],

    run: async(interaction, client) =>{
        const skipTo = interaction.options.getInteger('ตำแหน่ง')
        const player = interaction.client.manager.get(interaction.guild.id)
        const channel = interaction.member.voice.channel;
        const botChannel = interaction.guild.members.me.voice.channel;

        if(!player) return interaction.reply({content: `❌ **| ไม่มีเพลงเล่นในขณะนี้...**`, ephemeral: true})
        if(!channel) return interaction.reply({content:`⚠️ **| คุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.**`, ephemeral: true})
        if(channel && channel !== botChannel) return interaction.reply({content:`⚠️ **| คุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.**`, ephemeral: true})
        if(skipTo < 0 || skipTo > player.queue.size && player.queue.size !== 0) return await interaction.reply({content: `❌ **| คุณต้องระบุตัวเลขระหว่าง *\`<1-${player.queue.length}>\`***`, ephemeral: true})
            else if(player.queue.size === 0) return interaction.reply({content:`❌ **| คุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.\`***`, ephemeral: true})

        try {
           await player.stop(player.queue.size - skipTo)
           let embed = new EmbedBuilder()
            .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
            .setColor(EMBED_COLORS.SKIP)
            .setDescription(`> ⏭️ **ข้ามไปยังหมายเลขแทร็กเรียบร้อยแล้ว *\`${player.queue.length - 1}\`***`)
            .addFields([
                {name: `senpai~! :`, value: ("`" + interaction.member.user.username + "`"), inline: true}
            ])
            await interaction.reply({embeds: [embed]})
        }catch{}

    }
}