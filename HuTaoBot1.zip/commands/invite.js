const { EmbedBuilder } = require("discord.js");

const {EMBED_COLORS} = require('../config');

const config = require('../config');


module.exports = {
    name: 'invite',
    description: 'เชิญฉันเข้าเซิร์ฟเวอร์ของคุณ',

    run: async(interaction, client) =>{
        
        try{
            const member = interaction.member
            const client = interaction.client

            const embed = new EmbedBuilder()
            .setTitle('✅ Invite.')
            .setAuthor({name: client.user.username, iconURL: client.user.displayAvatarURL({dynamic: false})})
            .setThumbnail(client.user.displayAvatarURL())
            .setColor(EMBED_COLORS.SUCCESS)
            .setDescription(`**เราขอขอบคุณสำหรับการพิจารณาว่า *\`${client.user.tag}\`* เป็นประโยชน์สำหรับคุณ.** 
            
            
            > ***[[💠 เชิญNya~..!เข้าเซิร์ฟเวอร์ของคุณ]](https://discord.com/api/oauth2/authorize?client_id=${config.CLIENT_ID}&permissions=${config.PERMISSIONS}&scope=bot%20applications.commands)***
            
            > ***[[✨ ไม่ได้มี]](${config.SUPPORT_SERVER})***`)

            await interaction.reply({content: "📩 **| *ตรวจสอบ DM ของคุณ...***", ephemeral: true})
            member.send({embeds: [embed]}).catch((() => interaction.editReply({content: '❌ **| คุณไม่ได้เปิด DM ไว้...**', ephemeral: true})))
        }catch{}
    }
}