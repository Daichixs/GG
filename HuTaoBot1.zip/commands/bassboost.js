const { EmbedBuilder } = require("discord.js");

const {EMBED_COLORS} = require('../config.js')

module.exports = {
    name: 'bassboost',
    description: 'ตั้งระดับการเพิ่มเสียงเบสเป็นเพลงที่เล่น',
    options: [{
        name: 'ระดับ',
        description: 'ระดับการเพิ่มเสียงเบส',
        type: 3,
        required: true,
        choices: [
            {
                name: 'ค่าเริ่มต้น',
                value: 'ค่าเริ่มต้น',
            },
            {
                name: 'low',
                value: 'low',
            },
            {
                name: 'ต่ำ',
                value: 'ต่ำ',
            },
            {
                name: 'สูง',
                value: 'สูง',
            }
        ],
    }],

    run: async(interaction, client) =>{
        const player = interaction.client.manager.get(interaction.guild.id);
        let level = interaction.options.getString('ระดับ');
        const levels = {
            default: 0.0,
            low: 0.20,
            medium: 0.30,
            high: 0.35,
          };

        if(!player || !player.playing) return interaction.reply({content: `❌ **| ไม่มีเพลงเล่นในขณะนี้...**`, ephemeral: true});
        const channel = interaction.member.voice.channel;
        const botChannel = interaction.guild.members.me.voice.channel;

        if(!channel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยกับฉันค่ะถึงจะสามารถใช้คำสั่งได้.**`, ephemeral: true});
        if(channel && channel != botChannel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยกับฉันค่ะถึงจะสามารถใช้คำสั่งได้.**`, ephemeral: true});

        try {
            const bands = new Array(3).fill(null).map((_, i) => ({ band: i, gain: levels[level] }));
            await player.setEQ(...bands)
            const embed = new EmbedBuilder()
            .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
            .setColor(EMBED_COLORS.SUCCESS)
            .setDescription(`> ⏫ **ตั้งค่าระดับ BassBoost สำเร็จเป็น *\`${level}\`* **`)
            .addFields([
                {name: `senpai~!:`, value: ("`" + interaction.member.user.username + "`"), inline: true}
            ])

            interaction.reply({embeds: [embed]});

        }catch{}

    }
}