const Client = require('../index')
const { VoiceState ,EmbedBuilder } = require("discord.js");
const { EMBED_COLORS } = require("../config");



module.exports = async (client, oldState, newState) => {
  };    