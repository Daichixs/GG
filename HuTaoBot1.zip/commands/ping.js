const {EmbedBuilder} = require('discord.js')
const {EMBED_COLORS} = require('../config')
module.exports = {
    name: 'ping',
    description: 'ขอ ping ของบอท',

    run: async(interaction, client) =>{

        try{
            

            const message = await interaction.deferReply({fetchReply: true})
            const embed = new EmbedBuilder()
            .setTitle('🏓 PONG.')
            .setColor(EMBED_COLORS.SUCCESS)
            .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
            .setDescription(`> 💫 **เวลาในการตอบสนอง API ปัจจุบันของฉัน: *\`${interaction.client.ws.ping} ms\`* **
           
            > 🏷️ **ปิงปัจจุบันของฉัน: *\`${message.createdTimestamp - interaction.createdTimestamp} ms\`* **`)
            .addFields([
                {name: 'senpai~!', value: ("`"+interaction.member.user.username+"`"), inline: true}
            ])

            interaction.editReply({embeds: [embed]})

        }catch(e){console.log(e)}
        
    }
}