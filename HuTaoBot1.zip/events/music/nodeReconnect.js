var colors = require('colors');



module.exports = async (node) => {
    console.log(`[${colors.yellow('NODE')}] Trying To Reconnect To <${colors.cyan(`${node.options.identifier}`)}>`)
};