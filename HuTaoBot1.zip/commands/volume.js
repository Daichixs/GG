const {EmbedBuilder} = require('discord.js')

const {EMBED_COLORS} = require('../config.js')

module.exports = {
    name: 'volume',
    description: 'ตั้งระดับเสียงเพลง <0-100>',
    options: [{
        name: 'จำนวน',
        description: 'เลือกระดับเสียงเพลงที่ต้องกางระหว่าง 0 ถึง 100',
        type: 4,
        required: false,
    }],

    run: async(interaction, client) =>{
        const volume = interaction.options.getInteger('จำนวน')
        const player = interaction.client.manager.get(interaction.guild.id);

        if(!player) return interaction.reply({content: `❌ **| ไม่มีเพลงเล่นในขณะนี้...**`, ephemeral: true});
        const channel = interaction.member.voice.channel;
        const botChannel = interaction.guild.members.me.voice.channel;

        if(!channel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.**`, ephemeral: true});
        if(channel && channel != botChannel) return interaction.reply({content: `⚠️**| Yคุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.**`, ephemeral: true});
        if(!volume) return interaction.reply({content: `🔊 **| ปริมาณปัจจุบันถูกตั้งค่าเป็น\`${player.volume}\`**`, ephemeral: true});
            try {
                if(volume > 100 || volume < 0) return interaction.reply({content: `❌ **| คุณควรระบุค่าระหว่าง *\`<0-100>\`***`,ephemeral: true});
                
                await player.setVolume(volume);
                const embed = new EmbedBuilder()
                .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
                .setDescription(`> 🔊 **ตั้งค่าระดับเสียงเป็นสำเร็จ *\`${player.volume}\`* **`)
                .addFields([
                    {name: `senpai~!:`, value: ("`" + interaction.member.user.username + "`"), inline: true}
                ])
                .setColor(EMBED_COLORS.SUCCESS)
                await interaction.reply({embeds: [embed]})
                    

            }catch(e){
                console.log(e)
            }
    }
}