const {EmbedBuilder} = require('discord.js')

const {EMBED_COLORS} = require('../config')
const config = require('../config')
module.exports = {
    name: 'help',
    description: 'แสดงรายการคำสั่งที่มีทั้งหมด',

    run: async(interaction, client) =>{
        try{
            let Commands = interaction.client.slashCommands.map((cmd) =>`> ***\`/${cmd.name}\`*** **-** **${cmd.description}**`);
            const embed  = new EmbedBuilder()
            .setAuthor({name: `คำสั่งที่มีอยู่ทั้งหมดของ ${interaction.client.user.username}`, iconURL: interaction.client.user.displayAvatarURL()})
            .setColor(EMBED_COLORS.BLUE)
            .setImage('https://i.pinimg.com/originals/0c/af/9f/0caf9f7b8ab4917287aaaf8b8b772cd7.gif')
            .setFooter({text: `senpai~! ${interaction.member.user.username}`, iconURL: interaction.member.displayAvatarURL({dynamic: true})})
            .setDescription(`${Commands.join("\n")}
            
            > **[💠 เชิญNya~..!เข้าเซิร์ฟเวอร์ของคุณ](https://discord.com/api/oauth2/authorize?client_id=${config.CLIENT_ID}&permissions=${config.PERMISSIONS}&scope=bot%20applications.commands)**`)

            interaction.reply({embeds: [embed]})

        }catch{}
    }
}