var colors = require('colors');




module.exports = (player, track, ex) => {
    console.log(`[${colors.red('NodeError')}] Track Error: ${ex.error}`);
    console.debug(`[${colors.red('NodeError')}] [${colors.bgRed(`${player.guild}`)}] Track Error`)
}