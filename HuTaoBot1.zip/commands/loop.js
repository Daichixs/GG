const {EmbedBuilder} = require('discord.js')
const {EMBED_COLORS} = require('../config')

module.exports = {
    name: 'loop',
    description: 'เล่นเพลงซ้ำๆ',
    options: [{
        name: 'type',
        type: 3,
        description: 'คุณต้องการเล่นซ้ำแบบไหน',
        required: false,
        choices: [
            {
                name: 'คิว',
                value: 'คิว',
            },
            {
                name: 'เล่นซ้ำเพลงเดียว',
                value: 'เล่นซ้ำเพลงเดียว',
            },
        ],
    }],

    run: async(interaction, client) =>{
        const type = interaction.options.getString('type') || "เล่นซ้ำเพลงเดียว";
        const player = interaction.client.manager.get(interaction.guild.id)
        if(!player) return interaction.reply({content: `❌ **| ไม่มีเพลงเล่นในขณะนี้...**`, ephemeral: true});
        const channel = interaction.member.voice.channel;
        const botChannel = interaction.guild.members.me.voice.channel;

        if(!channel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยกับฉันค่ะถึงจะสามารถใช้คำสั่งได้.**`, ephemeral: true});
        if(channel && channel != botChannel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยกับฉันค่ะถึงจะสามารถใช้คำสั่งได้.**`, ephemeral: true});

        if(type === 'คิว'){
            try{
                await player.setQueueRepeat(!player.queueRepeat);
                const embed = new EmbedBuilder()
                .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
                .setDescription(`> ♾️ ***\`${player.queueRepeat ? 'เปิดใช้งาน': 'ปิดใช้งาน'}`)
                .addFields([
                    {name: `senpai~!`, value: ("`" + interaction.member.user.username + "`"), inline: true}
                ])
                .setColor(`${player.queueRepeat ? EMBED_COLORS.SUCCESS : EMBED_COLORS.ERROR}`)
                await interaction.reply({embeds: [embed]})
            }catch{}
        }
        else if(type === 'เล่นซ้ำเพลงเดียว'){
            try{
                await player.setTrackRepeat(!player.trackRepeat);
                const embed = new EmbedBuilder()
                .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
                .setDescription(`> 🔁 ***\`${player.trackRepeat ? 'เปิดใช้งาน': 'ปิดใช้งาน'}\`* วนซ้ำสำหรับเพลงเดียว.**`)
                .addFields([
                    {name: `senpai~!`, value: ("`" + interaction.member.user.username + "`"), inline: true}
                ])
                .setColor(`${player.trackRepeat ? EMBED_COLORS.SUCCESS : EMBED_COLORS.ERROR}`)
                await interaction.reply({embeds: [embed]})
            }catch{}
        }
    }
    
}