const { EmbedBuilder } = require("discord.js");
const msToHms = require("ms-to-hms");

const {EMBED_COLORS} = require('../config')

module.exports = {
    name: 'queue',
    description: 'คิวปัจจุบัน',
    options: [{
        name: 'page',
        description: 'หน้าคิวที่ต้องการดู',
        type: 4,
        required: false,
    }],

    run: async(interaction, client) =>{
        const page = interaction.options.getInteger('page');
        const player = interaction.client.manager.get(interaction.guild.id);
        if(!player) return interaction.reply({content: `❌ **| ไม่มีเพลงเล่นในขณะนี้...**`, ephemeral: true});
        const channel = interaction.member.voice.channel;
        const botChannel = interaction.guild.members.me.voice.channel;

        if(!channel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.**`, ephemeral: true});
        if(channel && channel != botChannel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยกับฉันค่ะถึงจะสามารถใช้คำสั่งได้.**`, ephemeral: true});

        const queue = player.queue;

        const embed = new EmbedBuilder()
        .setAuthor({name: `📑 The Current Queue`})
        .setColor(EMBED_COLORS.SUCCESS)

        try {
        const multiple = 10;
        const pagen = page || 1;

        const end = pagen * multiple;
        const start = end - multiple;

        const tracks = queue.slice(start, end);
        
        if(queue.current) embed.addFields([{name: `ปัจจุบัน: `, value: `**[${queue.current.title}](${queue.current.uri})**`}])
        if (!tracks.length) embed.setDescription(`ไม่มีแทร็กใน ${pagen > 1 ? `page ${pagen}` : "คิว"}.`);
        else embed.setDescription(tracks.map((track, i) => `\`${start + ++i}\` - **[${track.title}](${track.uri})**`).join("\n"));
        embed.addFields([{name: `ระยะเวลาของคิว:`, value: "***`"+(msToHms(queue.duration)+"`***"), inline: true}])
        const maxPages = Math.ceil(queue.length / multiple);

        embed.setFooter({ text: `Page ${pagen > maxPages ? maxPages : pagen} of ${maxPages}` });

        interaction.reply({embeds: [embed]})
        }catch{}
    
    }
}