const {EmbedBuilder} = require('discord.js');
const {EMBED_COLORS} = require('../config')
const msToHms = require('ms-to-hms')

module.exports = {
    name: 'grab',
    description: 'หยิบเพลงที่กำลังเล่นอยู่จะส่งไปใน DMs คุณ',

    run: async(interaction, client) =>{
        const player = interaction.client.manager.get(interaction.guild.id);

        if(!player || !player.playing) return interaction.reply({content: `❌ **| ไม่มีเพลงเล่นในขณะนี้...**`, ephemeral: true});
        const channel = interaction.member.voice.channel;
        const botChannel = interaction.guild.members.me.voice.channel;

        if(!channel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยกับฉันค่ะถึงจะสามารถใช้คำสั่งได้.**`, ephemeral: true});
        if(channel && channel != botChannel) return interaction.reply({content: `⚠️**| คุณต้องอยู่ในห้องพูดคุยกับฉันค่ะถึงจะสามารถใช้คำสั่งได้.**`, ephemeral: true});

        try{
            const current = player.queue.current;
            const embed = new EmbedBuilder()
            .setTitle(`✅ บันทึกแล้ว.`)
            .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
            .setDescription(`***[${current.title}](${current.uri})***`)
            .addFields([
                {name: '**⏲️ระยะเวลา**', value: current.isStream ? '\`🔴 LIVE\`' : `\`${msToHms(current.duration)}\``, inline: true},
                {name: '**🖋️ผู้เขียน**', value: "`" + current.author + "`", inline: true},
                {name: '**🌐ลิงค์**', value: "`" +current.uri+ "`", inline: false},
            ])
            .setColor(EMBED_COLORS.SUCCESS)
            if (typeof current.displayThumbnail === "การทำงาน") embed.setThumbnail(current.displayThumbnail("hqdefault"))

            await interaction.reply({content: "📩 **| *ตรวจสอบ DM ของคุณ...***", ephemeral: true})
            interaction.member.send({embeds: [embed]}).catch((() => interaction.editReply({content: '❌ **| คุณไม่ได้เปิด DM ไว้...**', ephemeral: true})))
        }catch {}
    }
}