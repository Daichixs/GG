const {Manager} = require('erela.js');
const Spotify = require('erela.js-spotify');
const Deezer = require('erela.js-deezer');
const Facebook = require('erela.js-facebook');
const config = require('../config.js');
require('dotenv').config();

const { EMBED_COLORS } = require("../config");
const { VoiceState ,EmbedBuilder, Embed } = require("discord.js");
const msToHms = require('ms-to-hms')

module.exports = (client) => {

    if(!config.SPOTIFY.CLIENT_ID && !config.SPOTIFY.CLIENT_SECRET){
        client.manager = new Manager({
            nodes: config.NODES,
            autoPlay: true,
            plugins: [
                new Facebook(),
                new Deezer({
                    albumLimit: config.DEEZER.ALBUM_LIMIT,
                    playlistLimit: config.DEEZER.PLAYLIST_LIMIT,
                }),
            ],
            send(id, payload) {
                var guild = client.guilds.cache.get(id);
                if (guild) guild.shard.send(payload);
            },
        });
    }
    else {
        client.manager = new Manager({
            nodes: config.NODES,
            autoPlay: true,
            plugins: [
                new Facebook(),
                new Deezer({
                    albumLimit: config.DEEZER.ALBUM_LIMIT,
                    playlistLimit: config.DEEZER.PLAYLIST_LIMIT,
                }),
                new Spotify({
                    clientID: config.SPOTIFY.CLIENT_ID,
                    clientSecret: config.SPOTIFY.CLIENT_SECRET,
                    albumLimit: config.SPOTIFY.ALBUM_LIMIT,
                    playlistLimit: config.SPOTIFY.PLAYLIST_LIMIT,
                    convertUnresolved: true,
                }),
            ],
            send(id, payload) {
                var guild = client.guilds.cache.get(id);
                if (guild) guild.shard.send(payload);
            },
        });
    }
    client.on("raw", (d) => client.manager.updateVoiceState(d));
    client.on('voiceStateUpdate', async(oldState, newState) =>{
        client.manager.updateVoiceState(oldState, newState)
        let guildId = newState.guild.id;
    const player = client.manager.get(guildId);
  
    // 
    if (!player || player.state !== "CONNECTED") return;
  
    // 
    const stateChange = {};
    // 
    if (oldState.channel === null && newState.channel !== null)
      stateChange.type = "JOIN";
    if (oldState.channel !== null && newState.channel === null)
      stateChange.type = "LEAVE";
    if (oldState.channel !== null && newState.channel !== null)
      stateChange.type = "MOVE";
    if (oldState.channel === null && newState.channel === null) return; // 
    if (newState.serverMute == true && oldState.serverMute == false)
      return player.pause(true);
    if (newState.serverMute == false && oldState.serverMute == true)
      return player.pause(false);
    // 
    if (stateChange.type === "MOVE") {
      if (oldState.channel.id === player.voiceChannel) stateChange.type = "LEAVE";
      if (newState.channel.id === player.voiceChannel) stateChange.type = "JOIN";
    }
    // 
    if (stateChange.type === "JOIN") stateChange.channel = newState.channel;
    if (stateChange.type === "LEAVE") stateChange.channel = oldState.channel;
  
    // 
    if (!stateChange.channel || stateChange.channel.id !== player.voiceChannel)
      return;
  
    // 
    stateChange.members = stateChange.channel.members.filter(
      (member) => !member.user.bot
    );
  
    switch (stateChange.type) {
      case "Join":
        if (stateChange.members.size === 1 && player.paused && player) {
          let emb = new EmbedBuilder()
            .setTitle(`Resuming paused queue`)
            .setAuthor({name: client.user.username, iconURL: client.user.displayAvatarURL({dynamic: false})})
            .setColor(EMBED_COLORS.PLAY)
            .setDescription(`> ▶️ **Resuming playback because *\`yay senpaii~! comee backk<a:1a9eefcd79d04f7abf4a06d134810103:1126123660965585076>\`* **`);
          await client.channels.cache.get(player.textChannel).send({ embeds: [emb] });
  
          player.pause(false);
        }
        break;
      case "Leave":
        if (stateChange.members.size === 0 && !player.paused && player.playing && player) {
          player.pause(true);
  
          let emb = new EmbedBuilder()
            .setTitle('Paused!')
            .setColor(EMBED_COLORS.STOP)
            .setAuthor({name: client.user.username, iconURL: client.user.displayAvatarURL({dynamic: false})})
            .setDescription(`> ⏸️ **Music has been paused *\`plsss comee back senpai~!!💕\`* **`);
          await client.channels.cache.get(player.textChannel).send({ embeds: [emb] });
        }
        break;
    }
    })
    client.manager.on('trackStart', async (player, track) => {
        const embeded = new EmbedBuilder()
        .setTitle(`<a:0ccafb29a6bb482b9e8ef1eb584bb263:1126123656905510952>`)
        if (typeof track.displayThumbnail === "function") 
            embeded.setThumbnail(track.displayThumbnail("hqdefault"))
        .setDescription(`**[${track.title}](${track.uri})**`)
        .setImage("https://i.imgur.com/QnyPmKH.gif?noredirect")
        .addFields([
            {name: '**ระยะเวลา**', value: track.isStream ? '\`🔴 LIVE\`' : `\`${msToHms(track.duration)}\``, inline: true},
            {name: '**ผู้เขียน**', value: "`" + track.author + "`", inline: true},
        ])
        .setColor(EMBED_COLORS.PLAY)
        .setFooter({text: `senpai~! : ${track.requester.user.username}`, iconURL: track.requester.displayAvatarURL({dynamic: true})})
        await client.channels.cache
          .get(player.textChannel)
          .send({embeds: [embeded]});
    })
    client.manager.on('queueEnd', async(player, track) =>{
        const channel = client.channels.cache.get(player.textChannel);
        let embed = new EmbedBuilder()
        .setAuthor({name: client.user.username, iconURL: client.user.displayAvatarURL({dynamic: false})})
        .setDescription(`> ✅ **| สิ้นสุดคิว**`)
        .setColor(EMBED_COLORS.QUEUE_END)
        channel.send({embeds: [embed]});
    })

}