var colors = require('colors');




module.exports = (player, track, ex) => {
    console.log(`[${colors.red('NodeError')}] Track Stuck: ${ex.error}`);
}