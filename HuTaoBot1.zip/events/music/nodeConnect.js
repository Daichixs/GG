var colors = require('colors')


module.exports = async(node)=> {
        console.log(`[${colors.green('NODE')}] Successfully Connected to <${colors.cyan(`${node.options.identifier}`)}>`)
}