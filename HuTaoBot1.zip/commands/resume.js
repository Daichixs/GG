const {EmbedBuilder} = require('discord.js');
const { EMBED_COLORS } = require('../config');

module.exports = {
    name: 'resume',
    description: 'เล่นเพลงที่เล่นอยู่ต่อ',

    run: async(interaction, client) =>{
        const player = interaction.client.manager.get(interaction.guild.id);
        if(!player) return interaction.reply({content: `❌ **| ไม่มีเพลงเล่นในขณะนี้...**`, ephemeral: true})
        const channel = interaction.member.voice.channel;
        const botChannel = interaction.guild.members.me.voice.channel;
        if(!channel) return interaction.reply({content:`⚠️ **| คุณต้องอยู่ในห้องพูดคุยก่อนจะสามารถใช้คำสั่งได้ค่ะ.**`, ephemeral: true});
        if(channel && channel !== botChannel) return interaction.reply({content: `⚠️ **| คุณต้องอยู่ในห้องพูดคุยกับฉันค่ะถึงจะสามารถใช้คำสั่งได้**`, ephemeral: true})

        if(player.paused){
            try{
                await player.pause(false);
                const embed = new EmbedBuilder()
                .setAuthor({name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL({dynamic: false})})
                .setDescription(`> ▶️ **Successfuly Resuming The Queue.**`)
                .addFields([
                    {name: `senpai~! :`, value: "`" + interaction.member.user.username + "`", inline: true},
                ])
                .setColor(EMBED_COLORS.PLAY)
                await interaction.reply({embeds: [embed]})

            }catch{}
        }else if(!player.paused) return interaction.reply({content: `❌ **| The Player Is Already Resuming.**`, ephemeral: true})
    }
}